document.getElementById('persona-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const nombre = document.getElementById('nombre').value;
  const apellido = document.getElementById('apellido').value;
  const edad = document.getElementById('edad').value;
  const sexo = document.getElementById('sexo').value;
  const email = document.getElementById('email').value;
  const telefono = document.getElementById('telefono').value;

  const tabla = document.querySelector('#tabla-personas tbody');
  const fila = document.createElement('tr');

  fila.innerHTML = `
    <td>${nombre}</td>
    <td>${apellido}</td>
    <td>${edad}</td>
    <td>${sexo}</td>
    <td>${email}</td>
    <td>${telefono}</td>
  `;

  tabla.appendChild(fila);

  // Limpiar el formulario
  this.reset();
});
