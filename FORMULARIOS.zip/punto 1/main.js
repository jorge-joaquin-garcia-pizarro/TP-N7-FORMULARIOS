const express = require("express");
const path = require("path");

const app = express();
const PORT = 3001;

let usuarios = [];

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Ruta para registrar usuario
app.post("/api/usuarios", (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email requerido" });
  }
  usuarios.push({ email });
  res.status(201).json({ mensaje: "Usuario registrado", usuarios });
});

// Ruta para obtener usuarios
app.get("/api/usuarios", (req, res) => {
  res.json(usuarios);
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
