document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("register-form");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirm-password");
    const passwordRequirements = document.getElementById("password-requirements");
    const passwordMismatch = document.getElementById("password-mismatch");
    const respuesta = document.getElementById("respuesta");
    const listaUsuarios = document.getElementById("lista-usuarios");
  
    // Cargar usuarios al iniciar
    cargarUsuarios();
  
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
  
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();
      const confirmPassword = confirmPasswordInput.value.trim();
  
      if (!validarEmail(email)) {
        mostrarError("Email inválido.");
        return;
      }
  
      if (!validarPassword(password)) {
        passwordRequirements.style.display = "block";
        return;
      } else {
        passwordRequirements.style.display = "none";
      }
  
      if (password !== confirmPassword) {
        passwordMismatch.style.display = "block";
        return;
      } else {
        passwordMismatch.style.display = "none";
      }
  
      try {
        const response = await fetch("/api/usuarios", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        });
  
        const data = await response.json();
        if (response.ok) {
          mostrarMensaje("Usuario registrado correctamente", "green");
          form.reset();
          cargarUsuarios(); // Actualiza la lista
        } else {
          mostrarError(data.error || "Error al registrar");
        }
      } catch (err) {
        mostrarError("Error de red");
      }
    });
  
    async function cargarUsuarios() {
      try {
        const res = await fetch("/api/usuarios");
        const data = await res.json();
  
        listaUsuarios.innerHTML = "";
        data.forEach(user => {
          const li = document.createElement("li");
          li.textContent = user.email;
          listaUsuarios.appendChild(li);
        });
      } catch (err) {
        console.error("Error al cargar usuarios");
      }
    }
  
    function validarEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
  
    function validarPassword(pass) {
      const cumpleLargo = pass.length === 10;
      const tieneMayus = /[A-Z]/.test(pass);
      const sinEspacios = !/\s/.test(pass);
      return cumpleLargo && tieneMayus && sinEspacios;
    }
  
    function mostrarError(msg) {
      respuesta.textContent = msg;
      respuesta.style.color = "red";
    }
  
    function mostrarMensaje(msg, color = "green") {
      respuesta.textContent = msg;
      respuesta.style.color = color;
    }
  });
  