const express = require("express");
const path = require("path");

const app = express();
const PORT = 3001;

let productos = [];

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

app.post("/api/productos", (req, res) => {
  const { deporte, herramienta, precio, disponibilidad } = req.body;
  if (!deporte || !herramienta || !precio || !disponibilidad) {
    return res.status(400).json({ error: "Todos los campos son obligatorios" });
  }

  const producto = { deporte, herramienta, precio, disponibilidad };
  productos.push(producto);
  res.status(201).json({ mensaje: "Producto registrado", productos });
});

app.get("/api/productos", (req, res) => {
  res.json(productos);
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
