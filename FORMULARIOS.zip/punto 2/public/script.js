document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("producto-form");
  const lista = document.getElementById("lista-productos");

  cargarProductos();

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const deporte = document.getElementById("deporte").value.trim();
    const herramienta = document.getElementById("herramienta").value.trim();
    const precio = document.getElementById("precio").value.trim();
    const disponibilidad = document.getElementById("disponibilidad").value;

    if (!deporte || !herramienta || !precio || !disponibilidad) {
      alert("Todos los campos son obligatorios");
      return;
    }

    const nuevo = { deporte, herramienta, precio, disponibilidad };

    try {
      const res = await fetch("/api/productos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nuevo)
      });

      if (!res.ok) throw new Error("Error al guardar");

      form.reset();
      cargarProductos();
    } catch (error) {
      alert("Error al enviar el formulario");
    }
  });

  async function cargarProductos() {
    try {
      const res = await fetch("/api/productos");
      const data = await res.json();

      lista.innerHTML = "";
      data.forEach(({ deporte, herramienta, precio, disponibilidad }) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${deporte}</td>
          <td>${herramienta}</td>
          <td>$${parseFloat(precio).toFixed(2)}</td>
          <td>${disponibilidad}</td>
        `;
        lista.appendChild(row);
      });
    } catch (err) {
      lista.innerHTML = "<tr><td colspan='4'>No se pudo cargar los productos</td></tr>";
    }
  }
});
